#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#define MAX 10000000

float average;
int minimum;
int maximum;
int arr[MAX];
int n;

void *th1(){

    int sum=0;
    for(int i=1;i<=n;i++)
            sum=sum+arr[i];
    average=(float)sum/n;
    return NULL;
}

void *th2(){

    minimum=arr[0];
    for(int i=1;i<n;i++)
        if(minimum>arr[i])
            minimum=arr[i];
    return NULL;
}

void *th3(){

    maximum=arr[0];
    for(int i=1;i<n;i++)
        if(maximum<arr[i])
            maximum=arr[i];
    return NULL;
}

int main(){
    
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }

    int t;

    pthread_t t1;
    pthread_t t2;
    pthread_t t3;

    t = pthread_create(&t1, NULL, &th1 ,NULL);
    pthread_join(t1,NULL);
    t = pthread_create(&t2, NULL, &th2 ,NULL);
    pthread_join(t2,NULL);
    t = pthread_create(&t3, NULL, &th3 ,NULL);
    pthread_join(t3,NULL);


    printf("The average value is %f \n",average);
    printf("The Minimum value is %d \n",minimum);
    printf("The Maximum value is %d \n",maximum);

    return 0;
}