// C Program that calculates various statistical values for a list of numbers.

// Code by Anirudh Jakhotia

// Neccessay Imports
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
// Inline function for maximum
#define MAX 10000000

// Declaration of variables

// Global variables to store various values such as avg,max,min;
int lowest,highest,list[MAX],len;
float mean;

//Thread1 function

//Function for thread1
void *thread1()
{
    int total = 0;
    for (int j = 1; j <= len; j++)
    {
        total = total + list[j];
    }
    mean = (float)total / len;
    return NULL;
}

//Function for thread2
void *thread2()
{
    lowest = list[0];
    for (int j = 1; j < len; j++)
    {
        if (lowest > list[j])
        {
            lowest = list[j];
        }
    }
    return NULL;
}

//Function for thread3
void *thread3()
{
    highest = list[0];
    for (int j = 1; j < len; j++)
    {
        if (highest < list[j])
        {
            highest = list[j];
        }
    }
    return NULL;
}

//Main Function
int main()
{
    //Taking the size of the array as input 
    printf("Enter the size of numbers to compute : ");
    scanf("%d", &len);

    //Entering the numbers
    printf("Enter the numbers : ");
    for (int j = 0; j < len; j++)
    {
        scanf("%d", &list[j]);
    }
    //Variable to store the thereads creation
    int temp;
    
    //Initializaing 3 thread worker objects
    pthread_t thr1;
    pthread_t thr2;
    pthread_t thr3;
    
    //Computing average using thread1
    temp = pthread_create(&thr1, NULL, &thread1, NULL);
    pthread_join(thr1, NULL);
    
    //Computing minimum using thread2
    temp = pthread_create(&thr2, NULL, &thread2, NULL);
    pthread_join(thr2, NULL);

    //Computing maximum using thread3
    temp = pthread_create(&thr3, NULL, &thread3, NULL);
    pthread_join(thr3, NULL);

    //Printing the desired values.
    printf("\n---------------------------------------\n");
    printf("PROBLEM 01 - OUTPUTS");
    printf("\n---------------------------------------\n\n");
    printf("The Average value is %f \n", mean);
    printf("The Minimum value is %d \n", lowest);
    printf("The Maximum value is %d \n", highest);

    //Return statement
    return 0;
}
//End of Main