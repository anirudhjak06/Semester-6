// C Program for producer and consumer problem using threads

// Code by Anirudh Jakhotia

// Neccessay Imports
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>

// Inline function for maximum
#define THREAD_NUM 8

// Initialzing a semaphore
sem_t vacant;
sem_t filled;

// Initilaizes a mutex with the specified attributes for use
pthread_mutex_t mbr;

// Global variables to store various values such as buffer and count
int total = 0, br[10];

//Function to compute the producer problem
void *manufacturer_compute(void *args)
{
    while (1)
    {
        int p = rand() % 100;
        sleep(1);
        sem_wait(&vacant);
        pthread_mutex_lock(&mbr);
        br[total] = p;
        printf("Produced %d\n", p);
        total++;
        pthread_mutex_unlock(&mbr);
        sem_post(&filled);
    }
}

//Function to compute the consumer problem
void *buyer_compute(void *args)
{
    while (1)
    {
        sem_wait(&filled);
        pthread_mutex_lock(&mbr);
        int q = br[total - 1];
        total--;
        pthread_mutex_unlock(&mbr);
        sem_post(&vacant);
        printf("Consumed %d\n", q);
        sleep(1);
    }
}

//Main Function
int main()
{
    //To generate random numbers everytime.
    srand(time(NULL));
    //Intializaing a thread variable for unique identification of thread 
    pthread_t threads[THREAD_NUM];
    pthread_mutex_init(&mbr, NULL);
    sem_init(&vacant, 0, 10);
    sem_init(&filled, 0, 0);
    int j;
    //For Block
    for (j = 0; j < THREAD_NUM; j++)
    {
        if (j > 0)
        {
            if (pthread_create(&threads[j], NULL, &manufacturer_compute, NULL) != 0)
                perror("Failed to create a thread");
        }
        else
        {
            if (pthread_create(&threads[j], NULL, &buyer_compute, NULL) != 0)
                perror("Failed to create a thread");
        }
    }
    for (j = 0; j < THREAD_NUM; j++)
        if (pthread_join(threads[j], NULL) != 0)
            perror("Failed to join a thread");

    sem_destroy(&vacant);
    sem_destroy(&filled);
    pthread_mutex_destroy(&mbr);
    
    //Return statement
    return 0;
}
//End of Main