package org.iiits.wbd.springbootsoapexample.service;

import org.springframework.stereotype.Service;
import wbd.iiits.org.spring_boot_soap_example.User;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    private static final Map<String, User> users = new HashMap<>();

    @PostConstruct
    public void initialize(){
        User user1 = new User();
        user1.setName("jack");
        user1.setEmpId(1);
        user1.setSalary(10.0d);
        User user2 = new User();
        user2.setName("jill");
        user2.setEmpId(2);
        user2.setSalary(20.0d);
        users.put(user1.getName(), user1);
        users.put(user2.getName(), user2);
    }

    public User getUsers(String name) {
        return users.get(name);
    }
}
