package org.iiits.wbd.client;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import org.iiits.wbd.consumingwebservice.wsdl.GetUserResponse;

@SpringBootApplication
public class ConsumingWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConsumingWebServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner lookup(UserClient quoteClient) {
        return args -> {
            String user = "jill";

            if (args.length > 0) {
                user = args[0];
            }
            GetUserResponse response = quoteClient.getUser(user);
            System.err.println(" User Name (Input): "+user);
            System.err.println(" User EmpID (Output from Service): "+ response.getUser().getEmpId());
            System.err.println(" User Salary (Output from Service): "+response.getUser().getSalary());
        };
    }

}