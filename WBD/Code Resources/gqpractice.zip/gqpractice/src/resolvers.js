const {UserInputError} = require('apollo-server')
let links = [
    {
        id: 'link-1',
        url: "http:\\iiits.ac.in",
        description: "Indian Institute of Information Technology Sricity",
        authorid: 'author-1'
    }
]

let authors = [
    {
        id: `author-1`,
        name: 'subu'
    }
]

const resolvers = {
    Query:{
        info: () => `hurray graphql works`,
        links: () => links,
        authors: () => authors,
        author: (parent, args) => {
            let author = authors.find((author)=> author.name === args.name)
            if(author==null){
                throw new UserInputError("The author does not exist in the database")
            }
            return author
        }
    },
    Link: {
        author: (link) => authors.find((author)=> author.id === link.authorid)
    },
    Author: {
        links: (author) => links.filter((link)=>link.authorid===author.id)
    },
    Mutation: {
        createLink: (parent, args) => {
            const linkCount = links.length
            const newLink = {
                id: `link-${linkCount+1}`,
                url: args.url,
                description: args.description
            }
            links.push(newLink)
            return newLink
        }
    }
}

module.exports = { resolvers }