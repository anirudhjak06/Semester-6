const rfs = require("rotating-file-stream");
const path = require("path");

const logsDir = path.resolve(process.cwd(), "logs")
console.log(logsDir)
const logs = rfs.createStream("access.log", {
  interval: "15m",
  path: logsDir,
});

module.exports = { logs };
