// import React from "react";
// // import { Link } from "react-router-dom";
// import Announcement from "../components/Announcement";
// import Footer from "../components/Footer";
// import Navbar from "../components/Navbar";
// // import Newsletter from "../components/Newsletter";
// // import styled from "styled-components";
// import "./Faq23.css";


// const Faq3 = () => {
  
//   return (
//     <div>
//         <Announcement />
//         <Navbar />
//         <script src="./Faq22.js"></script>
//         <body1>
//             <div class="top-image"></div>
//             <main class="container">
//                 <div class="content">
//                     <h1 class="content__title">FAQs</h1>

//                     <dl class="list">
//                         <dt class="list__word">
//                             <p>What is the cost of Product?</p>
//                             <span class="icon"></span>
//                         </dt>
//                         <dd class="list__description">
//                             You need not to pay for the products as these products are donated by different individuals and Green Grocery is working as a service provider to collect / verify/list / deliver these products. However a nominal shipping and handling charge will be applicable for delivering these products.
//                         </dd>

            
//                         <dt class="list__word">
//                             <p>How do I reset my password?</p>
//                             <i class="icon-arrow-down"></i>
//                             <span class="icon"> </span>
//                         </dt>
//                         <dd class="list__description">
//                             Click “Forgot password” from the login page or “Change password” from your profile page.
//                             A reset link will be emailed to you.
//                         </dd>

//                         <dt class="list__word">
//                             <p></p>I am not able to add the products in my cart!
//                             <span class="icon"></span>
//                         </dt>
//                         <dd class="list__description">
//                             Yes! Kindly log in before adding your products in the cart. If your are a new user please sign up to proceed further. You can also call us on our helpline for more assistance.</dd>

//                         <dt class="list__word">
//                             <p>Do you provide additional support?</p>
//                             <span class="icon"></span>
//                         </dt>
//                         <dd class="list__description" >
//                             Chat and email support is available 24/7. Phone lines are open during normal business hours.
//                         </dd>
//                     </dl>
//                 </div>
//             </main>
//         </body1>
//         <Footer/>
//     </div>
//   );
// };

// export default Faq3;