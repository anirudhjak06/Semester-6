// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB7S0XtlD0TjUigf896hpMFO6zyOqGoXUA",
  authDomain: "shop-de1b6.firebaseapp.com",
  projectId: "shop-de1b6",
  storageBucket: "shop-de1b6.appspot.com",
  messagingSenderId: "334968057132",
  appId: "1:334968057132:web:818e8c68cc7c2bf9461089"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;

